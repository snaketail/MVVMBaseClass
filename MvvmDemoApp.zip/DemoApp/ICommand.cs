﻿namespace DemoApp
{
    public interface ICommand
    {
    }
}