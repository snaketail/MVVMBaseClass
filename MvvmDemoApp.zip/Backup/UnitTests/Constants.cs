﻿namespace UnitTests
{
    static class Constants
    {
        public const string CUSTOMER_DATA_FILE = "/UnitTests;component/customers.xml";
    }
}